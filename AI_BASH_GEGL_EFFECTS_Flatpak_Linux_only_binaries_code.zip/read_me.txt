Edit bash-buddy.c and gegleffectspending.c and replace /home/contrast/tmp/ with your own directory with a search and replace command. The directory must be in home.

Then compile by clicking build.sh


Then put all binaries in    
 /home/(USERNAME)/.var/app/org.gimp.GIMP/data/gegl-0.4/plug-ins


If you want to compile everything including the operations that don't need to be edited and  compiled you can do that with the source code in the zip.
